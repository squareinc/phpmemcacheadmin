# Pupil Time Sync Protocol

The `Pupil Time Sync` protocol definition can be found in the [Pupil repository](https://github.com/pupil-labs/pupil/blob/master/pupil_src/shared_modules/time_sync_spec.md).
